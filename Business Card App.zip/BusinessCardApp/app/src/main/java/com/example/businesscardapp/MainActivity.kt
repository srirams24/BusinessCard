package com.example.businesscardapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.businesscardapp.ui.theme.BusinessCardAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BusinessCardAppTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Calling to  run  Business Card App on the Android
                    BusinessCardApp()
                }
            }
        }
    }
}

// Composable function Contains Profile and Contact sections arranged in vertical layout
@Composable
fun BusinessCardApp() {

    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .background(color = Color(0xFFD2E8D4))
            .fillMaxSize()

    )
    {
        // Profile UI Composable function Call
        ProfileSection(
            modifier = Modifier.weight(2.0F)
        )

        // Profile UI Composable function Call
        ContactSection(
            modifier = Modifier.weight(0.5F)
        )
    }
}

//Composable to create and arrange Profile photo and text compose in vertical order
@Composable
fun ProfileSection(modifier: Modifier = Modifier) {

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.profile),
            contentDescription = "Profile Image",
            modifier = Modifier
                .height(240.dp)
                .padding(16.dp)
                .border(width = 2.dp, color = Color(0xFF1D6E3B), shape = RectangleShape)
        )
        Text(
            text = stringResource(R.string.name_text),
            fontSize = 36.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(4.dp)
        )
        Text(
            text = stringResource(R.string.title_text),
            fontSize = 20.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF1D6E3B)
        )
    }
}

//Composable to arrange contact details in vertical layout
@Composable
fun ContactSection(modifier: Modifier = Modifier) {

    Column(
        modifier = modifier
    ) {

        ContactSubSection(
            textValue = stringResource(id = R.string.phone_no_text),
            icon = Icons.Default.Call,
            iconDescription = stringResource(id = R.string.phone_icon_text)
        )
        ContactSubSection(
            textValue = stringResource(id = R.string.mail_text),
            icon = Icons.Default.Email,
            iconDescription = stringResource(id = R.string.mail_icon_text)
        )
        ContactSubSection(
            textValue = stringResource(id = R.string.github_text),
            icon = Icons.Default.AccountCircle,
            iconDescription = stringResource(id = R.string.github_icon_text)
        )
    }
}

//Composable to create and arrange each contact detail contains text and icon in a row
@Composable
fun ContactSubSection(
    textValue: String,
    icon: ImageVector,
    iconDescription: String,
    modifier: Modifier = Modifier
) {

    Row(modifier = Modifier.padding(4.dp)) {
        Icon(icon, contentDescription = iconDescription, tint = Color(0xFF006D3B))
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = textValue,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF1D6E3B)
        )
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true
)
@Composable
fun BusinessCardAppPreview() {
    BusinessCardAppTheme {
        //To preview Business Card App in IDE
        BusinessCardApp()
    }
}